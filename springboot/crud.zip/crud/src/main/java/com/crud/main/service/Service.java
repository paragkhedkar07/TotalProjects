package com.crud.main.service;

import com.crud.main.entity.Author;


public interface Service {

	String addAuthor(Author author);

	

}
